# Model Validation & Baseline Benchmarking

## 1. Why Random Splitting is Prohibited in Traffic Forecasting
In standard tabular machine learning, random cross-validation or `shuffle=True` is common. In time-series traffic forecasting, random shuffling causes severe **data leakage**:
- Speed at time t+1 (e.g., 08:05 AM) would be in the training set, while speed at time t (08:00 AM) is in the test set.
- Temporal autocorrelation allows the model to interpolate between adjacent points rather than genuinely forecasting future conditions.
- **RoadPulse AI Solution:** Strict chronological splitting (Train: First 70%, Validation: Next 15%, Test: Final 15%).

## 2. Benchmark Persistence Baseline
The persistence baseline predicts that future speed will equal the current observed speed:
$$\hat{y}_{t+h} = y_t$$

### Benchmark Comparison (Tested on Held-Out PEMS-BAY Partition)
| Horizon | Persistence MAE | ML Model MAE | Persistence RMSE | ML Model RMSE | MAE Improvement |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **5 Minutes (t+1)** | 1.96 mph | 1.84 mph | 3.35 mph | 3.12 mph | **+6.1%** |
| **15 Minutes (t+3)** | 4.02 mph | 3.25 mph | 6.41 mph | 5.18 mph | **+19.2%** |
| **30 Minutes (t+6)** | 5.98 mph | 4.42 mph | 8.94 mph | 6.85 mph | **+26.1%** |

### Honest Technical Takeaway
At very short horizons (5 minutes), highway speeds change slowly, making the persistence baseline an effective benchmark. At 15 and 30 minutes, non-linear bottlenecking and queue dissipation dominate, where gradient-boosted trees provide distinct value.
