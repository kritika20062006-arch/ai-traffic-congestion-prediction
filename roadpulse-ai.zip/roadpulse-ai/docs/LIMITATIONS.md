# Limitations & Operational Boundaries

1. **Non-Causal Simulator:** The What-If Simulator provides synthetic sensitivity estimates based on macroscopic Greenshields relationships. It is an exploration tool, not a dynamic microscopic simulation (such as SUMO or Aimsun).
2. **Sensor Outage Sensitivity:** If physical loop hardware fails for over 30 consecutive minutes, predictions revert to temporal corridor averages.
3. **Anomalous Weather Conditions:** PEMS-BAY was collected in Northern California during spring/summer 2017. Regions with snow or severe icing require localized retraining.
4. **Horizon Decay:** Accuracy degrades past 30 minutes due to unobserved upstream ramp metering and incident shocks.
