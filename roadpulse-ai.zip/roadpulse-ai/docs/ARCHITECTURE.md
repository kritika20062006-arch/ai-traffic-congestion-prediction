# System Architecture & Information Flow

```
                      +---------------------------------------+
                      |         PEMS-BAY Sensor Stream        |
                      |  (5-min speeds across highway grid)   |
                      +---------------------------------------+
                                          |
                                          v
                      +---------------------------------------+
                      |        Preprocessing & Cleaning       |
                      |   - Forward fill gaps <= 15 min       |
                      |   - Timestamp index verification      |
                      +---------------------------------------+
                                          |
                                          v
                      +---------------------------------------+
                      |       Feature Engineering Pipeline    |
                      |   - Past lags: t-0 down to t-5        |
                      |   - Deltas (momentum) & acceleration  |
                      |   - Rolling statistics (mean, std)    |
                      |   - Cyclical sin/cos diurnal encodings|
                      |   [STRICT ZERO FUTURE DATA LEAKAGE]   |
                      +---------------------------------------+
                                          |
                      +-------------------+-------------------+
                      |                                       |
                      v                                       v
         +-------------------------+             +-------------------------+
         |     Training Mode       |             |     Inference Engine    |
         | (HistGradientBoosting)  |             |      (FastAPI REST)     |
         | - Chronological split   |             | - Validates history     |
         | - Targets: 5m, 15m, 30m |             | - Multi-horizon forecast|
         | - Validation residuals  |             | - Empirical reliability |
         +-------------------------+             +-------------------------+
                      |                                       |
                      v                                       v
         +-------------------------+             +-------------------------+
         |   Model & Residual Meta |             |   Adaptive Error Track  |
         |  (models/metadata.json) |             |  (Bias exponential EMA) |
         +-------------------------+             +-------------------------+
                                                              |
                                                              v
                                                 +-------------------------+
                                                 |   Responsive Dashboard  |
                                                 |  (HTML5/CSS3/Chart.js)  |
                                                 | - Horizon cards         |
                                                 | - Trajectory chart      |
                                                 | - Congestion lifecycle  |
                                                 | - What-If simulator     |
                                                 +-------------------------+
```

### Key Design Tenets
1. **Separation of Concerns:** Feature extraction logic is 100% unified across offline training and real-time inference via `backend/features.py`, preventing train-serve skew.
2. **Lightweight Footprint:** HistGradientBoostingRegressor utilizes histogram binning, running in seconds on standard laptops without GPU dependencies.
3. **Graceful Degeneration:** If backend models are absent, the client informs the user through clean setup-required states and uses bundled historical replay rather than fabricating runtime outputs.
