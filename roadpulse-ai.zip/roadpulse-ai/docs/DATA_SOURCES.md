# Data Sources & Schema Specification

## PEMS-BAY Specification
- **Dataset:** Caltrans PeMS Bay Area (PEMS-BAY)
- **Reference Record:** Zenodo 4264445 (Li et al., 2017)
- **Time Frequency:** 5 minutes (aggregated from raw 30-second loop detector pulses)
- **Spatial Coverage:** 325 detector stations in District 4 (San Francisco Bay Area)
- **Time Window:** 2017-01-01 00:00:00 to 2017-06-30 23:55:00 (52,116 time steps)

### Missing Value Treatment
- Loop detectors occasionally drop readings due to telemetry noise.
- Single or short missing bursts (<= 3 steps / 15 minutes) are forward-filled.
- Extended detector outages are removed to prevent artificial plateau artifacts.
