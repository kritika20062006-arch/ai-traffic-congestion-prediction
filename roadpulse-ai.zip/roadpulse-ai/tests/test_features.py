import numpy as np
import pandas as pd
import pytest
from backend.features import extract_features_from_history, build_supervised_dataset, FEATURE_NAMES


def test_feature_vector_dimension():
    recent_speeds = [65.0, 64.2, 63.8, 62.1, 60.5, 58.2]
    feat = extract_features_from_history(recent_speeds, timestamp_str="2017-05-15T08:00:00")
    assert feat.shape == (1, len(FEATURE_NAMES))
    assert feat[0, 0] == 58.2


def test_insufficient_history_rejection():
    with pytest.raises(ValueError):
        extract_features_from_history([60.0, 61.0, 62.0])


def test_no_future_leakage_in_supervised_builder():
    dates = pd.date_range("2017-01-01", periods=100, freq="5min")
    series = pd.Series(np.arange(100, dtype=float), index=dates)

    X, Y_dict = build_supervised_dataset(series, timestamps=dates)

    for idx in range(len(X)):
        row = X.iloc[idx]
        assert row["speed_t0"] > row["speed_lag1"]
        assert row["speed_lag1"] > row["speed_lag2"]
