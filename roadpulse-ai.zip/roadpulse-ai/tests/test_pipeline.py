import pandas as pd
import numpy as np
import pytest
from backend.preprocessing import chronological_split


def test_chronological_ordering():
    n = 100
    df = pd.DataFrame({"step": np.arange(n)})

    train_df, val_df, test_df = chronological_split(df, 0.70, 0.15, 0.15)

    assert len(train_df) == 70
    assert len(val_df) == 15
    assert len(test_df) == 15

    assert train_df["step"].max() < val_df["step"].min()
    assert val_df["step"].max() < test_df["step"].min()
