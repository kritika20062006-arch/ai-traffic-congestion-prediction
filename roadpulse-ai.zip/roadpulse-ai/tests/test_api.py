from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_health_endpoint():
    res = client.get("/health")
    assert res.status_code == 200
    data = res.json()
    assert "status" in data
    assert "model_ready" in data


def test_sensors_endpoint():
    res = client.get("/sensors")
    assert res.status_code == 200
    data = res.json()
    assert len(data["sensors"]) > 0


def test_predict_validation_rejects_empty():
    res = client.post("/predict", json={"sensor_id": "400001", "recent_speeds": []})
    assert res.status_code == 422


def test_predict_validation_rejects_negative_speed():
    res = client.post("/predict", json={
        "sensor_id": "400001",
        "recent_speeds": [60.0, 60.0, 60.0, 60.0, 60.0, -10.0]
    })
    assert res.status_code == 422


def test_predict_valid_payload():
    res = client.post("/predict", json={
        "sensor_id": "400001",
        "recent_speeds": [65.0, 64.0, 62.0, 60.0, 58.0, 55.0],
        "timestamp": "2017-05-15T08:00:00"
    })
    assert res.status_code == 200
    data = res.json()
    assert len(data["forecasts"]) == 3
    assert data["forecasts"][0]["horizon_minutes"] == 5
    assert data["forecasts"][1]["horizon_minutes"] == 15
    assert data["forecasts"][2]["horizon_minutes"] == 30


def test_provider_status_endpoint():
    res = client.get("/provider/status")
    assert res.status_code == 200
    data = res.json()
    assert "mode" in data
    assert "provider_name" in data
    assert "connection_status" in data


def test_provider_live_endpoint_fallback():
    res = client.get("/provider/live")
    assert res.status_code == 200
    data = res.json()
    assert "success" in data or "fallback_mode" in data

