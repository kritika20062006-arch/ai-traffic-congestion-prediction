@echo off
setlocal EnableDelayedExpansion

title RoadPulse AI - Model Training

echo ======================================================================
echo          RoadPulse AI: Model Training Pipeline
echo ======================================================================
echo.

if not exist "venv\Scripts\activate.bat" (
    echo [ERROR] Virtual environment not found. Please run run_windows.bat first.
    pause
    exit /b 1
)

call venv\Scripts\activate.bat

echo [INFO] Running model training on PEMS-BAY sensor data...
echo [INFO] Targets: 5-min, 15-min, and 30-min horizons.
echo [INFO] Split: 70%% Train, 15%% Validation, 15%% Test (Strict Chronological).
echo.

python backend/train.py

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Model training encountered an error.
    echo Verify that data/sample_pems_bay.csv or data/PEMS-BAY.csv exists.
    pause
    exit /b 1
)

echo.
echo [SUCCESS] Models trained and artifacts saved to models/ directory.
pause
