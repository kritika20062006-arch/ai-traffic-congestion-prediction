@echo off
setlocal EnableDelayedExpansion

title RoadPulse AI - Startup Launcher

echo ======================================================================
echo          RoadPulse AI: Traffic Speed Forecasting System
echo ======================================================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in your Windows PATH.
    echo Please install Python 3.10, 3.11, or 3.12 from https://www.python.org/
    echo Remember to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PY_VER=%%v
echo [OK] Detected Python version: %PY_VER%

if not exist "venv\Scripts\activate.bat" (
    echo [INFO] Creating local virtual environment in .\venv...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
)

call venv\Scripts\activate.bat
echo [OK] Virtual environment activated.

echo [INFO] Verifying installed packages...
python -m pip install --upgrade pip >nul 2>&1
pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] Dependency installation failed. Check internet connection.
    pause
    exit /b 1
)
echo [OK] Dependencies are up to date.

echo.
echo ======================================================================
echo  Starting RoadPulse AI Backend Server on http://localhost:8000
echo  - Interactive Dashboard : http://localhost:8000
echo  - Swagger API Docs      : http://localhost:8000/docs
echo  - System Health Check   : http://localhost:8000/health
echo ======================================================================
echo.

uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
pause
