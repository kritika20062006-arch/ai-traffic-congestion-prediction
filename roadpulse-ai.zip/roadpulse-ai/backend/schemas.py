"""Pydantic schemas for RoadPulse AI API validation.

Ensures strict request/response contracts for traffic forecasting,
model evaluation, baseline comparisons, and what-if simulations.
"""

from typing import List, Optional, Tuple, Dict, Any
from pydantic import BaseModel, Field, field_validator


class ModelMetadataInfo(BaseModel):
    model_type: str
    target_horizons_minutes: List[int]
    features_used: List[str]
    training_sensor_id: Optional[str] = None
    training_samples: Optional[int] = None
    trained_at: Optional[str] = None


class HealthResponse(BaseModel):
    status: str = Field(..., description="'healthy' or 'setup_required'")
    app_name: str = "RoadPulse AI"
    version: str = "1.0.0"
    model_ready: bool
    dataset_available: bool
    dataset_path: Optional[str] = None
    dataset_rows: Optional[int] = None
    available_sensors: List[str] = []
    model_info: Optional[ModelMetadataInfo] = None
    setup_message: Optional[str] = None


class SensorsResponse(BaseModel):
    sensors: List[str]
    total_count: int
    sampling_interval_minutes: int = 5
    default_sensor: Optional[str] = None
    dataset_source: str = "PEMS-BAY (Caltrans PeMS)"


class PredictRequest(BaseModel):
    sensor_id: str = Field(..., description="Sensor identifier from PEMS-BAY (e.g. '400001')")
    recent_speeds: List[float] = Field(
        ...,
        min_length=6,
        description="At least 6 consecutive 5-minute past speed observations in mph (covering >= 30 min)"
    )
    timestamp: Optional[str] = Field(
        default=None,
        description="ISO timestamp of the forecast origin, e.g. '2017-05-15T08:30:00'"
    )
    use_adaptive_correction: bool = Field(
        default=True,
        description="Apply empirical error correction based on recent tracking errors"
    )
    previous_prediction_error: Optional[float] = Field(
        default=0.0,
        description="Observed error (Actual - Forecast) from the previous 5-min step for adaptive bias correction"
    )

    @field_validator("recent_speeds")
    @classmethod
    def validate_speeds(cls, v: List[float]) -> List[float]:
        for speed in v:
            if speed < 0 or speed > 120:
                raise ValueError(f"Speed reading {speed} is out of physical range (0-120 mph)")
        return v


class ForecastItem(BaseModel):
    horizon_minutes: int
    horizon_steps: int
    predicted_speed_mph: float
    congestion_category: str
    category_color: str
    confidence_interval_80: Tuple[float, float]
    confidence_interval_95: Tuple[float, float]
    empirical_reliability_percent: float


class CongestionLifecycle(BaseModel):
    phase: str
    description: str
    trend_rate_mph_per_step: float
    is_estimate: bool = True


class TrafficFingerprint(BaseModel):
    comparison_method: str
    historical_mean_at_time: Optional[float] = None
    recent_deviation_mph: Optional[float] = None
    pattern_status: str
    similarity_score_pct: Optional[float] = None


class AdaptiveCorrectionInfo(BaseModel):
    applied: bool
    bias_adjustment_mph: float
    raw_5min_prediction_mph: float
    adjusted_5min_prediction_mph: float
    note: str


class PredictResponse(BaseModel):
    sensor_id: str
    forecast_origin_timestamp: Optional[str]
    current_speed_mph: float
    persistence_baseline_mph: float
    forecasts: List[ForecastItem]
    model_type: str
    congestion_lifecycle: CongestionLifecycle
    traffic_fingerprint: TrafficFingerprint
    adaptive_correction: AdaptiveCorrectionInfo
    data_source_mode: str = Field(..., description="'real_model', 'historical_replay', or 'demonstration_pipeline'")


class HorizonMetric(BaseModel):
    horizon_minutes: int
    ml_mae: float
    ml_rmse: float
    baseline_mae: float
    baseline_rmse: float
    mae_improvement_pct: float
    rmse_improvement_pct: float
    samples_evaluated: int


class EvaluateRequest(BaseModel):
    sensor_id: Optional[str] = None
    test_ratio: float = Field(default=0.15, ge=0.05, le=0.30)


class EvaluateResponse(BaseModel):
    sensor_id: str
    model_type: str
    split_method: str = "Strict Chronological (No Shuffle, No Future Leakage)"
    test_samples: int
    horizons: List[HorizonMetric]
    beats_baseline_overall: bool
    evaluation_status: str
    honesty_note: str


class SimulateRequest(BaseModel):
    sensor_id: str
    baseline_speeds: List[float] = Field(..., min_length=6)
    speed_shock_percent: float = Field(default=0.0, ge=-50.0, le=50.0)
    demand_shock_percent: float = Field(default=0.0, ge=-50.0, le=100.0)
    weather_condition: str = Field(default="Clear", description="'Clear', 'Rain', 'Dense Fog'")


class SimulateResponse(BaseModel):
    sensor_id: str
    speed_shock_percent: float
    demand_shock_percent: float
    weather_condition: str
    effective_speed_adjustment_mph: float
    original_forecasts: List[ForecastItem]
    simulated_forecasts: List[ForecastItem]
    simulation_disclaimer: str = (
        "Hypothetical simulation based on synthetic demand/capacity modifiers. "
        "Not causally validated or empirically observed in PEMS-BAY."
    )
