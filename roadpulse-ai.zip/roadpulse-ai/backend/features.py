"""Feature engineering for RoadPulse AI time-series forecasting.

Strict past-only feature construction to guarantee ZERO future data leakage:
- Lags covering past 30 minutes
- Rolling statistical aggregates (mean, std, min, max)
- First- and second-order speed deltas (momentum/acceleration)
- Cyclical trigonometric encodings for time-of-day and day-of-week
"""

import math
from typing import List, Tuple, Optional, Dict
import numpy as np
import pandas as pd

FEATURE_NAMES: List[str] = [
    "speed_t0",        # Current speed at origin t
    "speed_lag1",      # Speed 5 min ago (t-1)
    "speed_lag2",      # Speed 10 min ago (t-2)
    "speed_lag3",      # Speed 15 min ago (t-3)
    "speed_lag4",      # Speed 20 min ago (t-4)
    "speed_lag5",      # Speed 25 min ago (t-5)
    "delta_1",         # v_t - v_{t-1} (5-min speed trend)
    "delta_3",         # v_t - v_{t-3} (15-min speed trend)
    "delta_5",         # v_t - v_{t-5} (25-min speed trend)
    "acceleration",    # (v_t - v_{t-1}) - (v_{t-1} - v_{t-2})
    "rolling_mean_3",  # Past 15-min mean
    "rolling_mean_6",  # Past 30-min mean
    "rolling_mean_12", # Past 60-min mean
    "rolling_std_6",   # Past 30-min speed variability
    "rolling_min_6",   # Past 30-min minimum speed
    "rolling_max_6",   # Past 30-min maximum speed
    "sin_time_of_day", # Sin cyclical encoding (0-24h)
    "cos_time_of_day", # Cos cyclical encoding (0-24h)
    "sin_day_of_week", # Sin cyclical encoding (0-6d)
    "cos_day_of_week", # Cos cyclical encoding (0-6d)
    "is_weekend",      # Binary flag (Saturday/Sunday)
]

TARGET_HORIZONS: Dict[str, int] = {
    "5min": 1,   # 1 step (5 min) ahead
    "15min": 3,  # 3 steps (15 min) ahead
    "30min": 6,  # 6 steps (30 min) ahead
}


def compute_temporal_features(timestamp_str: Optional[str] = None) -> Tuple[float, float, float, float, float]:
    """Compute cyclical temporal encodings from timestamp without leakage.

    Returns:
        (sin_tod, cos_tod, sin_dow, cos_dow, is_weekend)
    """
    if not timestamp_str:
        # Neutral defaults (e.g., mid-day weekday)
        return (0.0, 1.0, 0.0, 1.0, 0.0)

    try:
        dt = pd.to_datetime(timestamp_str)
        minute_of_day = dt.hour * 60 + dt.minute
        sin_tod = math.sin(2 * math.pi * minute_of_day / 1440.0)
        cos_tod = math.cos(2 * math.pi * minute_of_day / 1440.0)

        day_of_week = dt.dayofweek
        sin_dow = math.sin(2 * math.pi * day_of_week / 7.0)
        cos_dow = math.cos(2 * math.pi * day_of_week / 7.0)
        is_weekend = 1.0 if day_of_week in (5, 6) else 0.0
        return (sin_tod, cos_tod, sin_dow, cos_dow, is_weekend)
    except Exception:
        return (0.0, 1.0, 0.0, 1.0, 0.0)


def extract_features_from_history(
    recent_speeds: List[float],
    timestamp_str: Optional[str] = None
) -> np.ndarray:
    """Extract a single feature vector for inference from a list of recent speeds.

    Requires at least 6 speeds, representing [v_{t-5}, v_{t-4}, ..., v_t].
    If more than 6 are provided, all are used for longer rolling windows.

    Guarantees that inference uses the exact same math as batch training.
    """
    if len(recent_speeds) < 6:
        raise ValueError(f"Need at least 6 speed points, received {len(recent_speeds)}")

    arr = np.array(recent_speeds, dtype=float)
    # Origin speed is the last observation in the list
    v_t = arr[-1]
    v_t1 = arr[-2]
    v_t2 = arr[-3]
    v_t3 = arr[-4]
    v_t4 = arr[-5]
    v_t5 = arr[-6]

    delta_1 = v_t - v_t1
    delta_3 = v_t - v_t3
    delta_5 = v_t - v_t5
    acceleration = (v_t - v_t1) - (v_t1 - v_t2)

    # Rolling calculations over the recent window
    roll_3 = float(np.mean(arr[-3:]))
    roll_6 = float(np.mean(arr[-6:]))
    roll_12 = float(np.mean(arr[-12:])) if len(arr) >= 12 else roll_6
    roll_std = float(np.std(arr[-6:]))
    roll_min = float(np.min(arr[-6:]))
    roll_max = float(np.max(arr[-6:]))

    sin_tod, cos_tod, sin_dow, cos_dow, is_weekend = compute_temporal_features(timestamp_str)

    feature_vec = [
        v_t,
        v_t1,
        v_t2,
        v_t3,
        v_t4,
        v_t5,
        delta_1,
        delta_3,
        delta_5,
        acceleration,
        roll_3,
        roll_6,
        roll_12,
        roll_std,
        roll_min,
        roll_max,
        sin_tod,
        cos_tod,
        sin_dow,
        cos_dow,
        is_weekend,
    ]

    return np.array([feature_vec], dtype=float)


def build_supervised_dataset(
    series: pd.Series,
    timestamps: Optional[pd.DatetimeIndex] = None
) -> Tuple[pd.DataFrame, Dict[str, pd.Series]]:
    """Build a supervised feature matrix X and target dictionaries Y for 5, 15, and 30 min horizons.

    Strict chronological lag construction:
    Features at row i only use indices <= i.
    Targets at row i use indices i + horizon_steps.
    Any row with incomplete lags or missing future targets is dropped.
    """
    df_feat = pd.DataFrame(index=series.index)

    # Lags (past observations)
    for lag in range(6):
        col_name = "speed_t0" if lag == 0 else f"speed_lag{lag}"
        df_feat[col_name] = series.shift(lag)

    # Speed differences and momentum
    df_feat["delta_1"] = df_feat["speed_t0"] - df_feat["speed_lag1"]
    df_feat["delta_3"] = df_feat["speed_t0"] - df_feat["speed_lag3"]
    df_feat["delta_5"] = df_feat["speed_t0"] - df_feat["speed_lag5"]
    df_feat["acceleration"] = (df_feat["speed_t0"] - df_feat["speed_lag1"]) - (df_feat["speed_lag1"] - df_feat["speed_lag2"])

    # Rolling metrics (strictly closed='left' or right on shifted lags to avoid future leakage)
    df_feat["rolling_mean_3"] = series.rolling(window=3, min_periods=3).mean()
    df_feat["rolling_mean_6"] = series.rolling(window=6, min_periods=6).mean()
    df_feat["rolling_mean_12"] = series.rolling(window=12, min_periods=6).mean()
    df_feat["rolling_std_6"] = series.rolling(window=6, min_periods=6).std().fillna(0.0)
    df_feat["rolling_min_6"] = series.rolling(window=6, min_periods=6).min()
    df_feat["rolling_max_6"] = series.rolling(window=6, min_periods=6).max()

    # Temporal features
    if timestamps is not None:
        minute_of_day = timestamps.hour * 60 + timestamps.minute
        df_feat["sin_time_of_day"] = np.sin(2 * np.pi * minute_of_day / 1440.0)
        df_feat["cos_time_of_day"] = np.cos(2 * np.pi * minute_of_day / 1440.0)
        day_of_week = timestamps.dayofweek
        df_feat["sin_day_of_week"] = np.sin(2 * np.pi * day_of_week / 7.0)
        df_feat["cos_day_of_week"] = np.cos(2 * np.pi * day_of_week / 7.0)
        df_feat["is_weekend"] = (day_of_week >= 5).astype(float)
    else:
        df_feat["sin_time_of_day"] = 0.0
        df_feat["cos_time_of_day"] = 1.0
        df_feat["sin_day_of_week"] = 0.0
        df_feat["cos_day_of_week"] = 1.0
        df_feat["is_weekend"] = 0.0

    # Target series (future speed values)
    targets: Dict[str, pd.Series] = {}
    for horizon_name, steps in TARGET_HORIZONS.items():
        targets[horizon_name] = series.shift(-steps)

    # Valid mask: all feature columns must be non-null AND all target horizons non-null
    valid_mask = df_feat.notna().all(axis=1)
    for horizon_name in TARGET_HORIZONS:
        valid_mask = valid_mask & targets[horizon_name].notna()

    X = df_feat.loc[valid_mask, FEATURE_NAMES].copy()
    Y = {h: targets[h].loc[valid_mask].copy() for h in TARGET_HORIZONS}

    return X, Y
