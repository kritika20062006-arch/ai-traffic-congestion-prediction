"""Data loading, cleaning, and chronological train/val/test splitting for PEMS-BAY.

Handles:
- Discovering real PEMS-BAY.csv, pems_bay.csv, or bundled sample data
- Explicit timestamp parsing and regular 5-minute frequency validation
- Handling missing/zero sensor readings with conservative forward-filling
- Strict chronological train/validation/test splitting (NO random shuffling)
"""

import os
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any
import pandas as pd
import numpy as np

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

POTENTIAL_DATA_FILES = [
    DATA_DIR / "PEMS-BAY.csv",
    DATA_DIR / "pems_bay.csv",
    DATA_DIR / "pems-bay.csv",
    DATA_DIR / "sample_pems_bay.csv",
]


def find_available_dataset() -> Optional[Path]:
    """Search for real PEMS-BAY dataset or bundled sample file."""
    for p in POTENTIAL_DATA_FILES:
        if p.exists() and p.stat().st_size > 0:
            return p
    return None


def get_dataset_metadata() -> Dict[str, Any]:
    """Return status metadata about data availability without loading the entire file into memory."""
    path = find_available_dataset()
    if path is None:
        return {
            "available": False,
            "path": None,
            "is_sample": False,
            "total_rows": 0,
            "sensor_count": 0,
            "sensors": [],
            "message": "No dataset found in data/. Download PEMS-BAY.csv from Zenodo (record 4264445) or use sample data."
        }

    is_sample = "sample" in path.name.lower()
    try:
        # Read header and first few rows to inspect columns and timestamps
        preview = pd.read_csv(path, nrows=10)
        time_col = preview.columns[0]
        sensor_cols = [c for c in preview.columns[1:] if str(c).strip()]

        # Estimate row count cheaply
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            total_lines = sum(1 for _ in f) - 1

        return {
            "available": True,
            "path": str(path.name),
            "is_sample": is_sample,
            "total_rows": total_lines,
            "sensor_count": len(sensor_cols),
            "sensors": [str(c) for c in sensor_cols[:25]],  # first 25 sensors
            "time_column": str(time_col),
            "message": "Real PEMS-BAY dataset active" if not is_sample else "Sample PEMS-BAY dataset active (testing mode)"
        }
    except Exception as e:
        return {
            "available": False,
            "path": str(path.name),
            "is_sample": is_sample,
            "total_rows": 0,
            "sensor_count": 0,
            "sensors": [],
            "message": f"Error inspecting dataset: {str(e)}"
        }


def load_pems_bay_data(
    selected_sensors: Optional[List[str]] = None,
    max_rows: Optional[int] = None
) -> Tuple[pd.DataFrame, pd.DatetimeIndex]:
    """Load and clean PEMS-BAY speed data.

    Returns:
        (df_speeds, datetime_index) where df_speeds has sensor IDs as columns.
    """
    path = find_available_dataset()
    if path is None:
        raise FileNotFoundError(
            "Neither PEMS-BAY.csv nor sample_pems_bay.csv was found in data/. "
            "Please follow data/README.md to place the dataset."
        )

    # Determine column names
    header_df = pd.read_csv(path, nrows=2)
    time_col = header_df.columns[0]
    all_sensor_cols = [str(c) for c in header_df.columns[1:]]

    usecols = [time_col]
    if selected_sensors:
        valid_requested = [c for c in selected_sensors if c in all_sensor_cols]
        if not valid_requested:
            # Fallback to first sensor if requested wasn't in file
            valid_requested = all_sensor_cols[:1]
        usecols.extend(valid_requested)
    else:
        # Load up to 10 sensors by default to conserve memory on lightweight machines
        usecols.extend(all_sensor_cols[:10])

    df = pd.read_csv(
        path,
        usecols=usecols,
        nrows=max_rows,
        parse_dates=[time_col]
    )

    df = df.sort_values(by=time_col).reset_index(drop=True)
    timestamps = pd.DatetimeIndex(df[time_col])
    speeds = df.drop(columns=[time_col])

    # Clean non-numeric or missing readings
    for col in speeds.columns:
        speeds[col] = pd.to_numeric(speeds[col], errors="coerce")
        # Forward fill up to 3 consecutive missing steps (15 mins)
        speeds[col] = speeds[col].ffill(limit=3).bfill(limit=3)
        # Clip speeds to realistic highway boundaries (0 - 90 mph)
        speeds[col] = speeds[col].clip(lower=0.0, upper=90.0)

    speeds.index = timestamps
    return speeds, timestamps


def chronological_split(
    df_or_series: Any,
    train_frac: float = 0.70,
    val_frac: float = 0.15,
    test_frac: float = 0.15,
) -> Tuple[Any, Any, Any]:
    """Split time-series data chronologically.

    STRICT GUARANTEE: No random shuffling. Train strictly precedes Validation,
    which strictly precedes Test.
    """
    assert abs((train_frac + val_frac + test_frac) - 1.0) < 1e-4, "Fractions must sum to 1.0"

    n = len(df_or_series)
    if n < 30:
        raise ValueError(f"Insufficient samples for 3-way split: {n} samples")

    train_end = int(n * train_frac)
    val_end = int(n * (train_frac + val_frac))

    train_part = df_or_series.iloc[:train_end]
    val_part = df_or_series.iloc[train_end:val_end]
    test_part = df_or_series.iloc[val_end:]

    return train_part, val_part, test_part
