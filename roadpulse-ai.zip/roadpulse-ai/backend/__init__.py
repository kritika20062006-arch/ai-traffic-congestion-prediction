"""RoadPulse AI: Adaptive Traffic Forecasting & Congestion Intelligence.

Backend package providing FastAPI endpoints, feature engineering,
scikit-learn regression pipelines, and baseline benchmarking.
"""

__version__ = "1.0.0"
