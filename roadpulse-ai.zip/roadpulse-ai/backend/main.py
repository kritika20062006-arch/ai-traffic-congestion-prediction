"""FastAPI Application for RoadPulse AI.

Provides RESTful endpoints for:
- Health and model readiness checks (/health)
- Available sensor metadata (/sensors)
- Supervised multi-horizon forecasting (/predict)
- Chronological model vs baseline evaluation (/evaluate, /metrics)
- What-If traffic demand and incident simulation (/simulate)
- Serving the frontend dashboard directly at http://localhost:8000
"""

import sys
from pathlib import Path
from typing import Dict, Any, List, Optional

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

CURRENT_DIR = Path(__file__).resolve().parent
ROOT_DIR = CURRENT_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from backend.preprocessing import get_dataset_metadata, find_available_dataset, load_pems_bay_data
from backend.predict import (
    are_models_loaded,
    get_model_metadata,
    predict_traffic,
)
from backend.evaluate import run_test_evaluation
from backend.schemas import (
    HealthResponse,
    SensorsResponse,
    PredictRequest,
    PredictResponse,
    EvaluateRequest,
    EvaluateResponse,
    SimulateRequest,
    SimulateResponse,
    ModelMetadataInfo,
)
from backend.provider import provider

app = FastAPI(
    title="RoadPulse AI — Traffic Forecasting API",
    description=(
        "Adaptive Traffic Speed Forecasting & Congestion Intelligence Engine. "
        "Predicts highway traffic speeds 5, 15, and 30 minutes ahead using PEMS-BAY "
        "sensor data, scikit-learn regressors, and persistence baseline benchmarks."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", response_model=HealthResponse)
def health_check() -> HealthResponse:
    """Return system health and model readiness status.

    Distinguishes application availability from model readiness.
    Never returns model_ready: true unless trained models actually exist.
    """
    models_ready = are_models_loaded()
    ds_meta = get_dataset_metadata()
    model_meta = get_model_metadata()

    model_info = None
    if models_ready and model_meta:
        model_info = ModelMetadataInfo(
            model_type=model_meta.get("model_type", "HistGradientBoostingRegressor"),
            target_horizons_minutes=[5, 15, 30],
            features_used=model_meta.get("features_used", []),
            training_sensor_id=model_meta.get("sensor_id"),
            training_samples=model_meta.get("sample_counts", {}).get("train"),
            trained_at=model_meta.get("trained_at")
        )

    if not ds_meta["available"]:
        setup_msg = "Setup Required: PEMS-BAY dataset missing in data/ directory. Follow data/README.md."
        sys_status = "setup_required"
    elif not models_ready:
        setup_msg = "Setup Required: ML models not trained yet. Run 'python backend/train.py' or 'train_model.bat'."
        sys_status = "setup_required"
    else:
        setup_msg = "System operational. Models loaded and ready for multi-horizon inference."
        sys_status = "healthy"

    return HealthResponse(
        status=sys_status,
        app_name="RoadPulse AI",
        version="1.0.0",
        model_ready=models_ready,
        dataset_available=ds_meta["available"],
        dataset_path=ds_meta["path"],
        dataset_rows=ds_meta["total_rows"],
        available_sensors=ds_meta["sensors"],
        model_info=model_info,
        setup_message=setup_msg
    )


@app.get("/sensors", response_model=SensorsResponse)
def get_sensors() -> SensorsResponse:
    """List available PEMS-BAY traffic sensors."""
    ds_meta = get_dataset_metadata()
    sensors = ds_meta.get("sensors", [])
    if not sensors:
        sensors = ["400001", "400017", "400030", "400040", "400045", "400057", "400072", "400085"]

    return SensorsResponse(
        sensors=sensors,
        total_count=len(sensors),
        sampling_interval_minutes=5,
        default_sensor=sensors[0] if sensors else None,
        dataset_source="PEMS-BAY (Caltrans PeMS Bay Area)"
    )


@app.get("/metrics")
def get_metrics() -> Dict[str, Any]:
    """Return cached evaluation metrics and model configuration."""
    model_meta = get_model_metadata()
    if not model_meta:
        return {
            "status": "not_trained",
            "message": "Models not yet trained. Run 'python backend/train.py' to generate benchmark metrics."
        }
    return {
        "status": "available",
        "model_type": model_meta.get("model_type"),
        "sensor_id": model_meta.get("sensor_id"),
        "sample_counts": model_meta.get("sample_counts"),
        "horizons": model_meta.get("horizons"),
        "trained_at": model_meta.get("trained_at")
    }


@app.post("/predict", response_model=PredictResponse)
def predict(request: PredictRequest) -> PredictResponse:
    """Forecast traffic speeds 5, 15, and 30 minutes ahead."""
    try:
        return predict_traffic(request)
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Inference error: {str(e)}"
        )


@app.post("/evaluate", response_model=EvaluateResponse)
def evaluate(request: EvaluateRequest) -> EvaluateResponse:
    """Perform or return held-out test evaluation against persistence baseline."""
    try:
        return run_test_evaluation(sensor_id=request.sensor_id, test_ratio=request.test_ratio)
    except FileNotFoundError as fnf:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(fnf)
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Evaluation failed: {str(e)}"
        )


@app.post("/simulate", response_model=SimulateResponse)
def simulate(request: SimulateRequest) -> SimulateResponse:
    """Simulate hypothetical traffic scenarios."""
    try:
        base_req = PredictRequest(
            sensor_id=request.sensor_id,
            recent_speeds=request.baseline_speeds,
            use_adaptive_correction=False
        )
        original_res = predict_traffic(base_req)

        weather_penalty_mph = 0.0
        if request.weather_condition.lower() == "rain":
            weather_penalty_mph = -4.5
        elif request.weather_condition.lower() == "dense fog":
            weather_penalty_mph = -3.0

        demand_penalty_mph = -(request.demand_shock_percent * 0.25)
        direct_speed_delta = (request.baseline_speeds[-1] * (request.speed_shock_percent / 100.0))
        net_adjustment = direct_speed_delta + demand_penalty_mph + weather_penalty_mph

        simulated_history = [
            float(max(5.0, min(80.0, s + net_adjustment)))
            for s in request.baseline_speeds
        ]

        sim_req = PredictRequest(
            sensor_id=request.sensor_id,
            recent_speeds=simulated_history,
            use_adaptive_correction=False
        )
        sim_res = predict_traffic(sim_req)

        return SimulateResponse(
            sensor_id=request.sensor_id,
            speed_shock_percent=request.speed_shock_percent,
            demand_shock_percent=request.demand_shock_percent,
            weather_condition=request.weather_condition,
            effective_speed_adjustment_mph=round(net_adjustment, 1),
            original_forecasts=original_res.forecasts,
            simulated_forecasts=sim_res.forecasts,
            simulation_disclaimer=(
                "Hypothetical simulation based on synthetic demand/capacity modifiers. "
                "Not causally validated or empirically observed in PEMS-BAY."
            )
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Simulation error: {str(e)}"
        )


@app.get("/provider/status")
def get_provider_status() -> Dict[str, Any]:
    """Return traffic data provider connection status, mode, and credentials state."""
    return provider.get_status()


@app.get("/provider/live")
async def get_live_traffic(point: str = "37.3861,-121.9640") -> Dict[str, Any]:
    """Fetch real-time traffic speed from connected live provider or return clear credentials status."""
    return await provider.fetch_live_speed(point=point)


FRONTEND_DIR = ROOT_DIR / "frontend"
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/")
    def serve_index():
        return FileResponse(str(FRONTEND_DIR / "index.html"))
