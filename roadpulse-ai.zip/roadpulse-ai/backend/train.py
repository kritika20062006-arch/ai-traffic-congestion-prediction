"""Supervised machine-learning training pipeline for RoadPulse AI.

Trains HistGradientBoostingRegressor models for 5-, 15-, and 30-minute horizons.
Benchmarks against the persistence baseline on a chronological validation split.
Saves model artifacts and empirical residual distributions for reliability intervals.
"""

import os
import sys
import json
import argparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error
import joblib

# Ensure backend package imports resolve
CURRENT_DIR = Path(__file__).resolve().parent
ROOT_DIR = CURRENT_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from backend.preprocessing import load_pems_bay_data, chronological_split
from backend.features import build_supervised_dataset, FEATURE_NAMES, TARGET_HORIZONS

MODELS_DIR = ROOT_DIR / "models"
MODELS_DIR.mkdir(parents=True, exist_ok=True)


def train_models_for_sensor(
    sensor_id: Optional[str] = None,
    max_rows: Optional[int] = 50000,
    random_seed: int = 42
) -> Dict[str, Any]:
    """Train multi-horizon gradient boosting regressors on real sensor history.

    Chronological split: 70% Train, 15% Validation, 15% Test.
    """
    print("=" * 60)
    print("RoadPulse AI — Supervised Time-Series Training Pipeline")
    print("=" * 60)

    # 1. Load data
    selected = [sensor_id] if sensor_id else None
    speeds_df, timestamps = load_pems_bay_data(selected_sensors=selected, max_rows=max_rows)

    actual_sensor = speeds_df.columns[0]
    print(f"[Data] Selected sensor: {actual_sensor} | Rows loaded: {len(speeds_df)}")
    sensor_series = speeds_df[actual_sensor]

    # 2. Extract features and target horizons
    X, Y_dict = build_supervised_dataset(sensor_series, timestamps=timestamps)
    print(f"[Features] Matrix shape: {X.shape} ({len(FEATURE_NAMES)} past-only features)")

    # 3. Chronological Train / Val / Test split
    X_train, X_val, X_test = chronological_split(X, train_frac=0.70, val_frac=0.15, test_frac=0.15)
    print(f"[Split] Chronological split without shuffling:")
    print(f"        Train: {len(X_train)} samples")
    print(f"        Val:   {len(X_val)} samples")
    print(f"        Test:  {len(X_test)} samples (held out)")

    metadata: Dict[str, Any] = {
        "sensor_id": str(actual_sensor),
        "trained_at": datetime.now(timezone.utc).isoformat(),
        "model_type": "HistGradientBoostingRegressor",
        "random_seed": random_seed,
        "features_used": FEATURE_NAMES,
        "sample_counts": {
            "train": len(X_train),
            "val": len(X_val),
            "test": len(X_test),
        },
        "horizons": {},
    }

    # Evaluate persistence baseline on validation set
    val_baseline_preds = X_val["speed_t0"].values

    for horizon_key, step_count in TARGET_HORIZONS.items():
        minutes = step_count * 5
        print(f"\n[Training] Horizon: {minutes} minutes ({step_count} step{'s' if step_count > 1 else ''} ahead)...")

        y_train = Y_dict[horizon_key].loc[X_train.index].values
        y_val = Y_dict[horizon_key].loc[X_val.index].values

        # HistGradientBoostingRegressor: fast, handles non-linear traffic dynamics well
        model = HistGradientBoostingRegressor(
            max_iter=120,
            learning_rate=0.08,
            max_leaf_nodes=31,
            min_samples_leaf=20,
            random_state=random_seed,
            loss="squared_error"
        )
        model.fit(X_train, y_train)

        # Predict on validation set
        y_val_pred = model.predict(X_val)

        # Compute ML metrics
        ml_mae = float(mean_absolute_error(y_val, y_val_pred))
        ml_rmse = float(np.sqrt(mean_squared_error(y_val, y_val_pred)))

        # Baseline metrics (Persistence: predict latest speed)
        base_mae = float(mean_absolute_error(y_val, val_baseline_preds))
        base_rmse = float(np.sqrt(mean_squared_error(y_val, val_baseline_preds)))

        # Residuals for empirical reliability intervals
        residuals = y_val - y_val_pred
        q80 = float(np.percentile(np.abs(residuals), 80))
        q95 = float(np.percentile(np.abs(residuals), 95))

        improvement_mae = ((base_mae - ml_mae) / base_mae * 100.0) if base_mae > 0 else 0.0
        improvement_rmse = ((base_rmse - ml_rmse) / base_rmse * 100.0) if base_rmse > 0 else 0.0

        print(f"    ML Model    -> MAE: {ml_mae:.2f} mph | RMSE: {ml_rmse:.2f} mph")
        print(f"    Persistence -> MAE: {base_mae:.2f} mph | RMSE: {base_rmse:.2f} mph")
        print(f"    Improvement vs Baseline: {improvement_mae:+.1f}% MAE")

        # Save model artifact
        model_filename = f"model_{minutes}min.joblib"
        model_path = MODELS_DIR / model_filename
        joblib.dump(model, model_path)

        metadata["horizons"][str(minutes)] = {
            "model_file": model_filename,
            "horizon_minutes": minutes,
            "horizon_steps": step_count,
            "val_ml_mae": round(ml_mae, 3),
            "val_ml_rmse": round(ml_rmse, 3),
            "val_baseline_mae": round(base_mae, 3),
            "val_baseline_rmse": round(base_rmse, 3),
            "mae_improvement_pct": round(improvement_mae, 2),
            "rmse_improvement_pct": round(improvement_rmse, 2),
            "residual_q80_mph": round(q80, 2),
            "residual_q95_mph": round(q95, 2),
            "empirical_reliability_pct": round(max(0.0, min(100.0, 100.0 - (ml_mae / 65.0 * 100.0))), 1)
        }

    # Save metadata
    metadata_path = MODELS_DIR / "metadata.json"
    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print("\n" + "=" * 60)
    print(f"Training Complete! Models and metadata saved to: {MODELS_DIR}")
    print("=" * 60)
    return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train RoadPulse AI traffic speed models.")
    parser.add_argument("--sensor", type=str, default=None, help="Specific sensor ID to train on")
    parser.add_argument("--max-rows", type=int, default=50000, help="Maximum rows to load")
    args = parser.parse_args()

    train_models_for_sensor(sensor_id=args.sensor, max_rows=args.max_rows)
