# RoadPulse AI — Adaptive Traffic Forecasting & Congestion Intelligence

RoadPulse AI is an end-to-end, lightweight machine learning system for forecasting highway traffic speeds 5, 15, and 30 minutes into the future using loop detector sensor data from the California Department of Transportation (Caltrans) PeMS Bay Area network (**PEMS-BAY**).

---

## 1. Quick Start Guide for Windows

### Prerequisites
- Windows 10 or 11
- Python 3.10, 3.11, or 3.12 (Check *"Add Python to PATH"* during installation)

### One-Click Startup
1. Double-click **`run_windows.bat`**.  
   *The launcher will automatically configure your virtual environment, install requirements, and start the FastAPI service on `http://localhost:8000`.*
2. Open your web browser and navigate to:  
   **[http://localhost:8000](http://localhost:8000)**
3. View the interactive Swagger API documentation at:  
   **[http://localhost:8000/docs](http://localhost:8000/docs)**

### Training the Models
1. To train the models on the bundled sample or full PEMS-BAY dataset, double-click **`train_model.bat`**.
2. Once complete, refresh `http://localhost:8000` to see real model weights active!

---

## 2. Running Automated Unit Tests
To verify pipeline integrity, feature non-leakage, and API contracts:
```bash
venv\Scripts\activate
pytest tests/ -v
```

---

## 3. Placement Interview Technical Reference

### Q1: Why use HistGradientBoostingRegressor instead of an LSTM or GRU?
> Deep recurrent architectures require GPU memory, are slow to retrain, and often overfit tabular loop detector speeds. `HistGradientBoostingRegressor` provides histogram binning, handles tabular lag dynamics, fits in seconds on standard CPUs, and achieves competitive MAE/RMSE results with complete reproducibility.

### Q2: Why is random cross-validation invalid for this dataset?
> Traffic speed data has high temporal autocorrelation ($R \approx 0.95$ across 5 minutes). Random shuffling leaks adjacent observations into the training set, causing artificial score inflation. We use strict chronological walk-forward splitting (70% Train, 15% Validation, 15% Test).

### Q3: Why does the Persistence Baseline perform well in 5-minute forecasts?
> At $h=1$ (5 minutes), physical traffic speeds rarely change drastically due to vehicle momentum. As a result, the persistence baseline achieves an MAE under 2.0 mph. However, as the horizon expands to 15 and 30 minutes, non-linear traffic breakdown occurs, where the ML model outperforms the baseline by capturing momentum, acceleration, and rolling speed statistics.
