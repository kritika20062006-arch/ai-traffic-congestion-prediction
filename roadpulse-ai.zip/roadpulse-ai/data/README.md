# PEMS-BAY Traffic Speed Dataset

## 1. Provenance & Official Source
- **Official Zenodo Record:** [https://zenodo.org/records/4264445](https://zenodo.org/records/4264445)
- **Collection Agency:** California Department of Transportation (Caltrans) Performance Measurement System (PeMS).
- **Geographic Area:** San Francisco Bay Area highway network.
- **Time Span:** January 1, 2017 to June 30, 2017 (6 full months).
- **Sensors:** 325 loop detector stations.
- **Aggregation Interval:** 5-minute intervals (288 observations per day per sensor).
- **Measured Variable:** Speed in Miles Per Hour (mph), operating predominantly between 0 and 70+ mph.

## 2. Dataset Setup on Windows
1. Visit the Zenodo archive: [https://zenodo.org/records/4264445](https://zenodo.org/records/4264445).
2. Download `pems-bay.h5` or `PEMS-BAY.csv`.
3. If distributed as CSV, place it directly at:
   ```
   roadpulse-ai/data/PEMS-BAY.csv
   ```
4. If distributed as HDF5, export the speed dataframe to CSV using Python:
   ```python
   import pandas as pd
   df = pd.read_hdf("pems-bay.h5")
   df.to_csv("data/PEMS-BAY.csv")
   ```

## 3. Bundled Verification Dataset
For out-of-the-box development and testing without downloading large multi-gigabyte files, this repository includes `data/sample_pems_bay.csv`. It contains authentic 5-minute speed sequences across 5 real PeMS detector stations (`400001`, `400017`, `400030`, `400040`, `400045`).
